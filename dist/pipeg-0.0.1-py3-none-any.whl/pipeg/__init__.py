from . import arithmetic
# from ctypes import CDLL
# import os
# import pyexample
# lib_path = os.path.join(os.path.dirname(__file__), 'pyexample')
# lib = CDLL(lib_path)
